<?php

return [

    'name'              => 'LuxeTemplate',
    'description'       => 'This is my awesome module',

];