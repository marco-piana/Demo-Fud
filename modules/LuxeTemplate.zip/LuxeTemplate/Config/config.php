<?php

return [
    'name' => 'LuxeTemplate'
];
